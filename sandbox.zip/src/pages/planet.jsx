import React from "react";

const Planet = () => {
  const [list, setList] = React.useState([]);
  const [listbk, setListBk] = React.useState([]);

  React.useEffect(() => {
    fetch("https://swapi.dev/api/planets")
      .then((response) => response.json())
      .then((resp) => {
        setList(resp.results);
        setListBk(resp.results);
      });
  }, []);

  const listItems = list.map((a) => (
    <div>
      <div className="col">{a.name}</div>
      <div
        title={a.population !== "unknown" ? a.population : ""}
        className="col"
      >
        {"\u{1F468}\u{1F468}\u{1F468}\u{1F468}\u{1F468}"}
      </div>
    </div>
  ));

  const checkinList = (val) => {
    let resp = listbk.filter((x, y) => x.name.toLowerCase().match(val));
    setList(resp ? resp : listbk);
  };

  return (
    <div>
      <div>Search for planets </div>
      <div>
        <input
          onChange={(e) => checkinList(e.target.value)}
          id="search"
          type="text"
        />
      </div>
      {/*
       * Replace the section below with the results of the search
       */}
      {list.length > 0 && (
        <section>
          <header>
            <div className="col">Name</div>
            <div className="col">Population</div>
          </header>
          {listItems}
        </section>
      )}
      <br />
      {list.length == 0 && (
        <div className="error">No planet matching search term</div>
      )}
    </div>
  );
};

export default Planet;
