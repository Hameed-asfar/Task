import React from "react";

const Login = (props) => {
  const [username, setUsername] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [error, setError] = React.useState("");

  const validUser = "Luke Skywalker";
  const validPass = "19BBY";

  const onSubmit = () => {
    if (validUser !== username) {
      setError("Enter valid user name");
    } else if (password !== validPass) {
      setError("Enter valid password");
    } else {
      setError("");
      props.onSuccess();
    }
  };
  return (
    <div className="flex-container">
      {error && <div> Error: {error} </div>}
      <div className="flex">
        <label className="label-login" htmlFor="username">
          Name{" "}
        </label>
        <input
          onChange={(e) => setUsername(e.target.value)}
          id="username"
          type="text"
        />
      </div>
      <br />
      <div className="flex">
        <label className="label-password" htmlFor="password">
          Password{" "}
        </label>
        <input
          onChange={(e) => setPassword(e.target.value)}
          id="password"
          type="password"
        />
      </div>
      <br />
      <div>
        <button onClick={onSubmit}>Submit</button>
      </div>
    </div>
  );
};

export default Login;
