import { configureStore } from '@reduxjs/toolkit';

export const store = configureStore({
    // Create the reducer and add it here
    reducer: {}
})