import React, { useState } from "react";
import "./App.css";
import Login from "./pages/login";
import Planet from "./pages/planet";
function App() {
  const [isLogin, setLogin] = useState(false);
  return (
    <div className="container">
      <h1>Star Wars</h1>
      {isLogin ? <Planet /> : <Login onSuccess={() => setLogin(true)} />}
    </div>
  );
}

export default App;
